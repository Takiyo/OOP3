// The turkey interface that every concrete turkey will implement
public interface Turkey {
	public void gobble();
	public void fly();
}
