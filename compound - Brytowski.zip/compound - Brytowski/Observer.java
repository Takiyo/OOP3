// Interface that every observer implements
public interface Observer {
	public void update(QuackObservable duck);
}
