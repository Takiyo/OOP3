//All display elements will inherit this. Currently just displays by
//printing to screen.
public interface DisplayElement {
	public void display();
}