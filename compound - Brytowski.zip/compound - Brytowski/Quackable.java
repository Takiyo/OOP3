// Quackable interface, every quacker implements this
public interface Quackable extends QuackObservable {
	public void quack();
}
