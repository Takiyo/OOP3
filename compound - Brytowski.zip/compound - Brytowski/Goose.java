// Class representing a goose
// Will be adapted to work with "quackable" accepting objects
public class Goose {

	public void honk() {
		System.out.println("Honk");
	}

	public String toString() {
		return "Goose";
	}
}
