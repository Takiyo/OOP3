// The duck interface that every concrete duck will implement.
public interface Duck {
	public void quack();
	public void fly();
}
